<?php

	//print_r($_POST);

include("db_config.php");
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	echo "connection successfully";
	if ((empty($_POST["h_username"])) && (empty($_POST["h_dept"])) && (empty($_POST["h_mobilno"])) && (empty($_POST["h_date"])) && (empty($_POST["h_pass"])) && (empty($_POST["h_repass"]))) {
		echo "please enter the entire field";
	}
	elseif (empty($_POST["h_username"])) {
		echo "please enter the hod username ";
	}
	elseif (empty($_POST["h_dept"])) {
		echo "please enter the hod department";
	}
	elseif (empty($_POST["h_mobilno"])) {
		echo "please enter the hod mobile number";
	}
	elseif (empty($_POST["h_date"])){
		echo "please enter the hod date of birth";
	}
	elseif (empty($_POST["h_pass"])) {
		echo "please enter the hod password";
	}
	elseif (empty($_POST["h_repass"])) {
		echo "please enter the hod  retype password";
	}
	elseif (strcmp($_POST["h_pass"], $_POST["h_repass"]) !=0) {
		echo "Password And Retype Password Are Not Equals";
	}
	else{
		$username=$_POST["h_username"];
		$dept=$_POST["h_dept"];
		$mobile=$_POST["h_mobilno"];
		$dob=$_POST["h_date"];
		$pass=$_POST["h_pass"];

		$sql="SELECT * FROM `hod` WHERE `username`='".$username."' and `dept`='".$dept."' ";
		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);

		if ($count==1) {
			echo "first step is verified";
			echo "<br>";
			
			$sql1="SELECT `username`, `gmail`, `dept`, `address`, `gender`, `mobileno`, `dateogbirth`, `password` FROM `hod` WHERE dept = '".$dept."' And mobileno='".$mobile."' ";
			$result=mysqli_query($con,$sql1);
			$row1=mysqli_fetch_array($result);
			$count_1=mysqli_num_rows($result);

			if ($count_1==1) {
				echo "second step is verified";
				$sql4="UPDATE `hod` SET `password` = '".$pass."' WHERE dept = '".$dept."' ";
				if ($con->query($sql4)==true) {
					echo "password updated successfully";
					header('location: ../hod_login.html');
				}
				else{
					echo "password not updated some errors".$con."";
				}
				
			}
			else{
				echo "wrong mobile number in the correct username";
			}
		}
		else{
			echo "wrong username and department";
		}
	}
}



?>