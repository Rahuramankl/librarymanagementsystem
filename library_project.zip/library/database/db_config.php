
<?php

	$server="localhost";
	$user="root";
	$pass="";
	$db="library1";
	$con =new  mysqli($server,$user,$pass,$db);



?>