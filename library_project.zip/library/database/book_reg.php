<?php

	//print_r($_POST);
	include 'db_config.php';

	if ($con->connect_error) {
		die('connection failed'.$con->connect_error);
	}
	else{
		//echo "connection successfully";
		if ((empty($_POST["book_no"])) && (empty($_POST["book_name"])) && (empty($_POST["book_title"])) && (empty($_POST["book_rack"])) && (empty($_POST["book_rate"])) && (empty($_POST["book_edition"])) && (empty($_POST["book_author"])) && (empty($_POST["book_public"])) && (empty($_POST["book_reg_date"])) && (empty($_POST["book_count"])) && (empty($_POST["book_regulation"])) && (empty($_POST["book_dept"])) && (empty(
	$_POST["book_author_type"]))) {
			echo "Please Fill The Entire Fields";
		}
		elseif (empty($_POST["book_no"])) {
			echo "Please Enter The BookNumber";
		}
		elseif (empty($_POST["book_name"])) {
			echo "Please Enter The BookName";
		}
		elseif (empty($_POST["book_title"])) {
			echo "Please Enter The BookTitle";
		}
		elseif (empty($_POST["book_rack"])) {
			echo "Please Enter The BookRack";
		}
		elseif (empty($_POST["book_rate"])) {
			echo "Please Enter The BookRate";
		}
		elseif (empty($_POST["book_edition"])) {
			echo "Please Enter The Book Edition";
		}
		elseif (empty($_POST["book_author"])) {
			echo "Please Enter The Book Author";
		}
		elseif (empty($_POST["book_public"])) {
			echo "Please Enter The Book Publication";
		}
		elseif (empty($_POST["book_reg_date"])) {
			echo "Please Enter The Book Registeration Date";
		}
		elseif (empty($_POST["book_count"])) {
			echo "Please Enter The Book Counting";
		}
		elseif (empty($_POST["book_regulation"])) {
			echo "Please Enter The Book Regulation";
		}
		elseif (empty($_POST["book_author_type"])) {
			echo "Please Enter The Book Author Type";
		}
		elseif (empty($_POST["book_dept"])) {
			echo "Please Enter The Book Department";
		}
		else{
			$bookno=$_POST["book_no"];
			$bookname=$_POST["book_name"];
			$booktitle=$_POST["book_title"];
			$bookrack=$_POST["book_rack"];
			$bookrate=$_POST["book_rate"];
			$bookedition=$_POST["book_edition"];
			$bookauthor=$_POST["book_author"];
			$bookpublic=$_POST["book_public"];
			$bookregdate=$_POST["book_reg_date"];
			$bookcount=$_POST["book_count"];
			$bookregulation=$_POST["book_regulation"];
			$book_a_type=$_POST["book_author_type"];
			$bookdept=$_POST["book_dept"];

			$sql="INSERT INTO `book_reg`(`book_ref`, `bookname`, `booktitle`, `bookrack`, `bookrate`, `bookedition`, `bookauthor`, `publication`, `bookreg_date`, `noofbooks`, `regulation`, `author_type`, `bookdept`) VALUES ('".$bookno."' , '".$bookname."' , '".$booktitle."' , '".$bookrack."' , '".$bookrate."' , '".$bookedition."' , '".$bookauthor."' , '".$bookpublic."' , '".$bookregdate."' , '".$bookcount."' , '".$bookregulation."' , '".$book_a_type."' , '".$bookdept."')";

			if ($con->query($sql)==true) {
				echo "inserted successfully";
			}
			else{
				echo "error".$con."";
			}

		}
	}


?>