<?php
	if ((empty($_POST["stud_reg"])) && (empty($_POST["stud_name"])) && (empty($_POST["stud_dept"])) && (empty($_POST["stud_phone"])) && (empty($_POST["stud_mail"])) && (empty($_POST["stud_gender"])) && (empty($_POST["stud_add"])) && (empty($_POST["stud_dob"])) && (empty($_POST["stud_current_year"])) && (empty($_POST["stud_pass"])) && (empty($_POST["stud_repass"])) ) {
		echo "Please Fill The Entire Fields";
	}
	elseif (empty($_POST["stud_reg"])) {
		echo "Please fill the register number";
	}
	elseif (empty($_POST["stud_name"])) {
		echo "please fill the student name ";
	}
	elseif (empty($_POST["stud_dept"])) {
		echo "please fill the student department";
	}
	elseif (empty($_POST["stud_phone"])) {
		echo "please fill the student phone number";
	}
	elseif (empty($_POST["stud_mail"])) {
		echo "please fill the student maill id";
	}
	elseif (empty($_POST["stud_gender"])) {
		echo "please fill the student gender";
	}
	elseif (empty($_POST["stud_add"])) {
		echo "please fill the student address";
	}
	elseif (empty($_POST["stud_dob"])) {
		echo "please fill the student date of birth";
	}
	elseif (empty($_POST["stud_current_year"])) {
		echo "please fill the student current year";
	}
	elseif (empty($_POST["stud_pass"])) {
		echo "please fill the student password";
	}
	elseif (empty($_POST["stud_repass"])) {
		echo "please fill the student retype password";
	}
	elseif (strcmp($_POST["stud_repass"], $_POST["stud_pass"]) !=0) {
		echo "password and retype password or not equals ";
	}
	//elseif (empty($_FILES["image"])) {
	//	echo "please enter the your profile";
	//}

	else{
		include("db_config.php");
		if ($con->connect_error) {
			die('connection failed'.$con->connect_error);
		}
		else{
			//echo "connection successfully";
				//$target_dir = "uploads/";
				$target_dir="../uploads/".basename($_FILES["FileUpload"]["name"]);
				$imageFileType = strtolower(pathinfo($target_dir,PATHINFO_EXTENSION));

				print_r($_FILES["FileUpload"]);	
				// Check if file already exists
				if (file_exists($target_file)) {
  						echo "Sorry, file already exists.";
  						//$uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
  					echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  					//$uploadOk = 0;
				}

				
				if (move_uploaded_file($_FILES["FileUpload"]["tmp_name"], $target_dir)) {
						echo "file uploaded successfully";
						$image=$_FILES["FileUpload"]["name"];

						$regno=$_POST["stud_reg"];
						$sql="SELECT `regno`, `name`, `dept`, `mobile`, `gmail`, `gender`, `address`, `dob`, `current_year`, `pass` FROM `student` WHERE `regno`= '".$regno."' ";
						$res=mysqli_query($con,$sql);
						$row=mysqli_fetch_array($res);
						$count=mysqli_num_rows($res);
						if ($count==1) {
							echo "Already Use In This Register Number";
						}
						else{
								$name=$_POST["stud_name"];
								$dept=$_POST["stud_dept"];
								$mobile=$_POST["stud_phone"];
								$gmail=$_POST["stud_mail"];
								$gender=$_POST["stud_gender"];
								$add=$_POST["stud_add"];
								$dob=$_POST["stud_dob"];
								$current_year=$_POST["stud_current_year"];
								$pass=$_POST["stud_pass"];
								echo "New User Registeration Number";
								$sql1="INSERT INTO `student`(`regno`, `name`, `dept`, `mobile`, `gmail`, `gender`, `address`, `dob`, `current_year`, `pass`, `image`) VALUES ('".$regno."','".$name."','".$dept."','".$mobile."','".$gmail."','".$gender."','".$add."','".$dob."','".$current_year."','".$pass."','".$image."')";
								if ($con->query($sql1)==true) {
									echo "Record Inserting Successfully ";
									header('location: ../stud_login.html');
								}
								else{
										echo "error".$sql1."";
								}
						}
				}
				else{
						echo "file not uploaded";
				}	
		}
	}


?>