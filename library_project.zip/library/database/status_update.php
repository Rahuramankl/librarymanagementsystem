<?php
	
	print_r($_POST);


	$regno = $_POST["regno"];
	$refno = $_POST["refno"];
	$status = $_POST["status"];

	include('db_config.php');


	if ($con->connect_error) {
		die('connection failed'.$con->connect_error);
	}
	else{
		echo "connection successfully";
		echo "<br>";
		if ((empty($regno)) && (empty($refno)) && (empty($status))) {
			header('location: order_view.php');
		}
		else{
			if ($status=="accept") {
				//echo "accepted";
				$sql = "SELECT * FROM `book_reg` where `book_ref`='$refno'";
				$res=mysqli_query($con,$sql);
				$row=mysqli_fetch_array($res);
				$count=mysqli_num_rows($res);
				if ($count==1) {
					echo "login success";
					$book_count = $row['noofbooks'];
					//echo $book_count;
					$b_count = $book_count-1;
					$sql1 = "UPDATE `stud_order` set `b_count`='$b_count' WHERE  `refno`='$refno' AND `status` IS NULL";
					$out = $con->query($sql1);
					if ($out == true) {
						echo "<br>";
						echo "stud order table updated";
						$sql2 = "UPDATE `book_reg` SET `noofbooks`='$b_count' WHERE `book_ref`='$refno'";
						$output = $con->query($sql2);
						if ($output ==true) {
							echo "<br>";
							echo "book registeration table updated";
							echo "<br>";
							$sql3 = "UPDATE `stud_order` SET `b_count`=1, `status`='accepted' WHERE `regno`='$regno' AND `refno`='$refno'";
							$out1 = $con->query($sql3);
							if ($out1 == true) {
								echo "Accepted";
							}
							else{
								echo "<br>";
								echo "not accepted";
							}
						}
						else{
							echo "book registeration table not updated";
						}
					}
					else{
						echo "stud order table not updated";
					}
				}
				else{
					echo "login failed";
				}
			}
			else{
				echo $status;
				$sql4 = "SELECT * FROM `stud_order`";
				$out2 = $con->query($sql4);
				if ($out2==true) {
				 	echo "query true";

				 } 
				 else{
				 	echo "query failed";
				 }
			}
			
		}
	}


?>