<?php


//print_r($_POST);

include('db_config.php');

if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	echo "connection successfully";

	if ((empty($_POST["regno"])) && (empty($_POST["sname"])) && (empty($_POST["dept"])) && (empty($_POST["mail"])) && (empty($_POST["mobile"])) && (empty($_POST["gender"])) && (empty($_POST["bname"])) && (empty($_POST["refno"])) && (empty($_POST["c_year"])) && (empty($_POST["bcount"])) && (empty($_POST["edition"])) && (empty($_POST["rackno"])) && (empty($_POST["reason"])) && (empty($_POST["reject"]))) {
		echo "please enter the all fields";
	}
	elseif (empty($_POST["regno"])) {
		echo "Please Enter The Register Number";
	}
	elseif (empty($_POST["sname"])) {
		echo "Please Enter The Name";
	}
	elseif (empty($_POST["dept"])) {
		echo "Please Enter The Department";
	}
	elseif (empty($_POST["mail"])) {
		echo "Please Enter The MailId";
	}
	elseif (empty($_POST["mobile"])) {
		echo "Please Enter The Mobile Number";
	}
	elseif (empty($_POST["gender"])) {
		echo "Please Enter The Gender";
	}
	elseif (empty($_POST["bname"])) {
		echo "Please Enter The Book Name";
	}
	elseif (empty($_POST["refno"])) {
		echo "Please Enter The Reference Number";
	}
	elseif (empty($_POST["c_year"])) {
		echo "Please Enter The Current Year";
	}
	elseif (empty($_POST["bcount"])) {
		echo "Please Enter The Book Counting";
	}
	elseif (empty($_POST["edition"])) {
		echo "Please Enter The Book Edition";
	}
	elseif (empty($_POST["rackno"])) {
		echo "Please Enter The Rack Number";
	}
	elseif (empty($_POST["reason"])) {
		echo "Please Enter The Reason";
	}
	elseif (empty($_POST["reject"])) {
		echo "Please Enter The Rejection ";
	}
	else{
		echo "all is correct";
		$regno = $_POST["regno"];
		$refno = $_POST["refno"];
		$status = $_POST["reject"];
		$reason = $_POST["reason"];
		/*$rackno = $_POST["rackno"];
		$edition = $_POST["edition"];
		$bcount = $_POST["bcount"];
		$c_year = $_POST["c_year"];
		$bname = $_POST["bname"];
		$gender = $_POST["gender"];
		$mobile = $_POST["mobile"];
		$mail = $_POST["mail"];
		$dept = $_POST["dept"];
		$sname = $_POST["sname"];*/


		$sql = "UPDATE `stud_order` SET `status`='$status',`reason`='$reason' WHERE `regno`='$regno' AND `refno`='$refno' ";

		$res = $con->query($sql);
		if ($res == true) {
			echo "Rejection Success";
		}
		else{
			echo "some thing error";
		}

	}
}


?>