<?php


session_start();





//print_r($_POST);
include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	//echo "connection successfully";
	if ((empty($_POST["stud_reg"])) && (empty($_POST["stud_pass"]))) {
		echo "please enter the register number and name";
	}
	elseif (empty($_POST["stud_reg"])) {
		echo "please enter the student register number";
	}
	elseif (empty($_POST["stud_pass"])) {
		echo "please enter the student password";
	}
	else{
		$regno=$_POST["stud_reg"];
		$pass=$_POST["stud_pass"];
		


		$sql="SELECT `regno`, `name`, `dept`, `mobile`, `gmail`, `gender`, `address`, `dob`, `current_year`, `pass` FROM `student` WHERE `regno`='".$regno."' And `pass`='".$pass."' ";
		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);
		if ($count==1) {
			
			$_SESSION["regno"] = $regno;
			$_SESSION["password"] = $pass;
		
			echo "Login Successfully";
			header('location: stud_bookdept.php');
		}
		else{
			echo "Login Failed".$row."";
		}
	}
}




?>