<?php

include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	//echo "Connection SuccessFully";

	$sql="SELECT * FROM book_reg ORDER BY bookrack Asc";

	$res=$con->query($sql);
	if($res==true){
		//echo "query true";
	}
	else{
		echo "query failed";
	}
}
?>
<div class="table-responsive table-sm">
	<table class="table  table-hover">
		<thead class="bg-dark text-white">
			<tr>
				<th>Ref_No</th>
				<th>Name</th>
				<th>Title</th>
				<th>Rate</th>
				<th>Edition</th>
				<th>Author</th>
				<th>Publication</th>
				<th>RegDate</th>
				<th>counting</th>
				<th>Regulation</th>
				<th>Type</th>
				<th>Dept</th>
				<th>Rack</th>
			</tr>
		</thead>
		<tbody >
			<?php
				if ($res->num_rows>0) {
					while ($row=$res->fetch_assoc()) {
						echo "<tr>";
						echo "<td>{$row["book_ref"]}</td>";
						echo "<td>{$row["bookname"]}</td>";
						echo "<td>{$row["booktitle"]}</td>";
						echo "<td>{$row["bookrate"]}</td>";
						echo "<td>{$row["bookedition"]}</td>";
						echo "<td>{$row["bookauthor"]}</td>";
						echo "<td>{$row["publication"]}</td>";
						echo "<td>{$row["bookreg_date"]}</td>";
						echo "<td>{$row["noofbooks"]}</td>";
						echo "<td>{$row["regulation"]}</td>";
						echo "<td>{$row["author_type"]}</td>";
						echo "<td>{$row["bookdept"]}</td>";
						echo "<td>{$row["bookrack"]}</td>";
						echo "</tr>";
					}
				}else{
					echo "empty";
				}


			?>
		</tbody>
	</table>
</div>