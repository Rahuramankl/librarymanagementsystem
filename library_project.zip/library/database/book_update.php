<?php

	session_start();

	$book_ref=$_SESSION["book_ref"];
	//print_r($_POST);

	if ((empty($_POST["bookname"])) && (empty($_POST["booktitle"])) && (empty($_POST["bookrack"])) &&  (empty($_POST["bookrate"])) && (empty($_POST["bookedition"])) && (empty($_POST["bookauthor"])) && (empty($_POST["publication"])) && (empty($_POST["noofbooks"])) && (empty($_POST["regulation"])) && (empty($_POST["author_type"])) && (empty($_POST["bookdept"])) ) {
		echo "Please Fill The Entire Fields";
	}
	elseif (empty($_POST["bookname"])) {
		echo "please enter the BookName";
	}
	elseif (empty($_POST["booktitle"])) {
		echo "please enter the BookTitle";
	}
	elseif (empty($_POST["bookrack"])) {
		echo "please enter BookRack";
	}
	elseif (empty($_POST["bookrate"])) {
		echo "please enter BookRate";
	}
	elseif (empty($_POST["bookedition"])) {
		echo "please enter BookEdition";
	}
	elseif (empty($_POST["bookauthor"])) {
		echo "please enter AuthorName";
	}
	elseif (empty($_POST["publication"])) {
		echo "please enter the Publicaiton";
	}
	elseif (empty($_POST["noofbooks"])) {
		echo "please enter the Book Counting";
	}
	elseif (empty($_POST["regulation"])) {
		echo "please enter the regulation";
	}
	elseif (empty($_POST["author_type"])) {
		echo "please enter the Author Type";
	}
	elseif (empty($_POST["bookdept"])) {
		echo "please enter the Book Department";
	}
	else{
		//echo "all fields are corrected";
		include('db_config.php');
		if ($con->connect_error) {
			die('connection failed'.$con->connect_error);
		}
		else{
			//echo "connection successfully";
			
			//echo $book_ref;
			$bookname=$_POST["bookname"];
			$booktitle=$_POST["booktitle"];
			$bookrack=$_POST["bookrack"];
			$bookrate=$_POST["bookrate"];
			$bookedition=$_POST["bookedition"];
			$bookauthor=$_POST["bookauthor"];
			$publication=$_POST["publication"];
			$noofbooks=$_POST["noofbooks"];
			$regulation=$_POST["regulation"];
			$author_type=$_POST["author_type"];
			$bookdept=$_POST["bookdept"];

			$sql="UPDATE `book_reg` SET `bookname`='".$bookname."',`booktitle`='".$booktitle."',`bookrack`='".$bookrack."',`bookrate`='".$bookrate."',`bookedition`='".$bookedition."',`bookauthor`='".$bookauthor."',`publication`='".$publication."',`noofbooks`='".$noofbooks."',`regulation`='".$regulation."',`author_type`='".$author_type."',`bookdept`='".$bookdept."' WHERE `book_ref`='".$book_ref."'";

			if ($con->query($sql)==true) {
				echo "Book Details Updated SuccessFully";
				//header('location : ../b_reg.hml');
				$sql1 ="UPDATE `stud_order` SET `b_count`='$noofbooks',`b_name`='$bookname',`b_dept`='$bookdept',`edition`='$bookedition',`rackno`='$bookrack',`regulation`='$regulation' WHERE `refno`='$book_ref' AND `status` IS NULL";
				$output = $con->query($sql1);
				if ($output == true) {
					echo "Book Order Updated SuccessFully";
				}
				else{
					echo "Book Updation Is Error";
				}
			}
			else{
				echo "error".$con;
			}
		}
	}
unset($_SESSION["book_ref"]);
//session_destroy();
?>