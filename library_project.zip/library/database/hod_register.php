<?php
//print_r($_POST);
include("db_config.php");
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	echo "connection sucessfully";
	if ((empty($_POST["h_name"])) && (empty($_POST["h_email"])) && (empty($_POST["h_pass"])) && (empty($_POST["h_repass"])) && (empty($_POST["h_date"])) && (empty($_POST["h_dept"])) && (empty($_POST["h_mobileno"])) && (empty($_POST["h_gender"])) && (empty($_POST["h_address"]))) {
		echo "please enter entire filed";
	}
	elseif (empty($_POST["h_name"])) {
		echo "please fill name condiction";
	}
	elseif (empty($_POST["h_email"])){
		echo "please fill email condiction";
	}
	elseif (empty($_POST["h_pass"])){
		echo "please fill password condiction";
	}
	elseif (empty($_POST["h_repass"])){
		echo "please fill repassword condiction";
	}
	elseif (strcmp($_POST["h_pass"],$_POST["h_repass"])!=0) {
		echo "please fill password and retypepassword are not same";
	}
	elseif (empty($_POST["h_date"])){
		echo "please fill date condiction";
	}
	elseif (empty($_POST["h_dept"])){
		echo "please fill dept condiction";
	}
	elseif (empty($_POST["h_mobilno"])){
		echo "please fill mobilno condiction";
	}
	elseif (empty($_POST["h_gender"])){
		echo "please fill gender condiction";
	}
	elseif (empty($_POST["h_address"])){
		echo "please fill Address condiction";
	}
	else{
		if ($con->connect_error) {
			die('connection failed'.$con->connect_error);
		}
		else{
			//echo "connection successfully";
				$name=$_POST["h_name"];
				$email=$_POST["h_email"];
				$pass=$_POST["h_pass"];
				$dob=$_POST["h_date"];
				$dept=$_POST["h_dept"];
				$mobilno=$_POST["h_mobilno"];
				$gender=$_POST["h_gender"];
				$Address=$_POST["h_address"];


			$sql="SELECT `username`, `gmail`, `dept`, `address`, `gender`, `mobileno`, `dateogbirth`, `password` FROM `hod` WHERE dept ='".$dept."'";
			
			$res=mysqli_query($con,$sql);
			$row=mysqli_fetch_array($res);
			$count=mysqli_num_rows($res);
			if ($count==1) {
				echo "Already Use in this department";
			}
			else{
				
				echo "new user";

				$sql="INSERT INTO `hod`(`username`, `gmail`, `dept`, `address`, `gender`, `mobileno`, `dateogbirth`, `password`) VALUES ('".$name."','".$email."','".$dept."','".$Address."','".$gender."','".$mobilno."','".$dob."','".$pass."')";
				if ($con->query($sql)==true) {
					echo "record insert sucessfully";
					header('location: ../hod_login.html');
				}
				else{
					echo "error".$sql."";
		
				}

			}
		}	

	}
}
?>