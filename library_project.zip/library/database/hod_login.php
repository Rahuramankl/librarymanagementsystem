<?php

session_start();

//print_r($_POST);
include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	//echo "connection successfully";
	if ((empty($_POST["h_username"])) && (empty($_POST["h_dept"])) &&(empty($_POST["h_pass"]))) {
		echo "please enter the username and dept and password";
	}
	elseif (empty($_POST["h_username"])) {
		echo "please enter the hod username";
	}
	elseif (empty($_POST["h_dept"])) {
		echo "please enter the hod dept";
	}
	elseif (empty($_POST["h_pass"])) {
		echo "please enter the hod password";
	}
	else{
		$username=$_POST["h_username"];
		$dept=$_POST["h_dept"];
		$pass=$_POST["h_pass"];


		$sql="SELECT `username`, `gmail`, `dept`, `address`, `gender`, `mobileno`, `dateogbirth`, `password` FROM `hod` WHERE username ='".$username."' And dept ='".$dept."'";

		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);
		if ($count==1) {
			echo "Login Successfully";
			$sql2="SELECT * FROM `hod` WHERE username ='".$username."' And password ='".$pass."'";

			$res2=mysqli_query($con,$sql2);
			$row2=mysqli_fetch_array($res2);
			$count2=mysqli_num_rows($res2);
			if ($count2==1) {
				echo "login successfully";
				$_SESSION["username"] = $username;
				$_SESSION["dept"] = $dept;
				header('location:hod_unsubmit.php');
				# code...
			}
			else{
				echo "login failed";
			}
		}

		else{
			echo "Login Failed".$row."";
		}
	}
}

?>
