<?php

include('db_config.php');
if ($con->connect_error) {
	die('connection faild'.$con->connect_error);
}
else{
	echo "connection Successfully";
	echo "<br>";
	if ((empty($_POST["lib_uid"])) && (empty($_POST["lib_email"])) && (empty($_POST["lib_mobile"])) && (empty($_POST["lib_dob"])) && (empty($_POST["lib_pass"])) && (empty($_POST["lib_repass"]))) {
		echo "Please Fill The Entire Fields";
	}
	elseif (empty($_POST["lib_uid"])) {
		echo "Please Enter The UserId";
	}
	elseif (empty($_POST["lib_email"])) {
		echo "Please Enter The EmailId";
	}
	elseif (empty($_POST["lib_mobile"])) {
		echo "Please Enter The Mobile Number";
	}
	elseif (empty($_POST["lib_dob"])) {
		echo "Please Enter The Date Of Birth";
	}
	elseif (empty($_POST["lib_pass"])) {
		echo "Please Enter The Password";
	}
	elseif (empty($_POST["lib_repass"])) {
		echo "Please Enter The Retype Password";
	}
	elseif (strcmp($_POST["lib_pass"], $_POST["lib_repass"]) !=0) {
		echo "Please Enter Correct Password And Retype Password";
	}
	else{

		$uid=$_POST["lib_uid"];
		$email=$_POST["lib_email"];
		$mobile=$_POST["lib_mobile"];
		$dob=$_POST["lib_dob"];
		$pass=$_POST["lib_pass"];

		$sql="SELECT * FROM `lib_incharge` WHERE `userid`='".$uid."'  And  `email`='".$email."' ";

		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);

		if ($count==1) {
			echo "First Step Is Verified";
			echo "<br>";

			$sql1="SELECT * FROM `lib_incharge` WHERE `userid`='".$uid."'  And  `mobile`='".$mobile."' ";
			
			$result=mysqli_query($con,$sql1);
			$row=mysqli_fetch_array($result);
			$count1=mysqli_num_rows($result);
			if ($count1==1) {
				echo "Second Step Is Verified";
				echo "<br>";

				$query="UPDATE `lib_incharge` SET `password`='".$pass."' WHERE `userid`='".$uid."' ";
				if ($con->query($query)==true) {
					echo "Password Updated Successfully";
					header('location: ../lib_incharge.html');
				}
				else{
					echo "Error";
				}
			}
			else{
				echo "Invalid Mobile And UserId";
			}

		}
		else{
			echo "Invalid UserId And EmailId";
		}

	}
}



?>