<?php

//print_r($_POST);

include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	if ((empty($_POST["regno"])) && (empty($_POST["refno"]))) {
		echo "please to login";
		header('location: lib_work.php');
	}
	else{
			$regno = $_POST["regno"];
			$refno = $_POST["refno"];
			$date = date('d-m-y : h:i:sa');
			echo $date;
			
			//echo "connection successfully";
			$sql = "UPDATE `stud_order` SET `sub_status`='submited',`sub_date`='$date' WHERE `regno`='$regno' AND `refno`='$refno'";
			$res= $con->query($sql);
			if ($res == true) {
				echo "Submited SuccessFully";
			}
			else{
				echo "Submission Failed";
			}
		}

}


?>