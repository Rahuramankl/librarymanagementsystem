-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 26, 2021 at 02:45 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_reg`
--

CREATE TABLE `book_reg` (
  `book_ref` bigint(60) NOT NULL,
  `bookname` varchar(60) DEFAULT NULL,
  `booktitle` varchar(70) DEFAULT NULL,
  `bookrack` int(70) DEFAULT NULL,
  `bookrate` bigint(60) DEFAULT NULL,
  `bookedition` int(70) DEFAULT NULL,
  `bookauthor` varchar(80) DEFAULT NULL,
  `publication` varchar(90) DEFAULT NULL,
  `bookreg_date` date DEFAULT NULL,
  `noofbooks` int(90) DEFAULT NULL,
  `regulation` varchar(80) DEFAULT NULL,
  `author_type` varchar(80) DEFAULT NULL,
  `bookdept` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_reg`
--

INSERT INTO `book_reg` (`book_ref`, `bookname`, `booktitle`, `bookrack`, `bookrate`, `bookedition`, `bookauthor`, `publication`, `bookreg_date`, `noofbooks`, `regulation`, `author_type`, `bookdept`) VALUES
(2, 'c', 'c language', 2, 500, 1, 'balasubramani', 'technical', '2019-09-25', 3, '2017', 'LocalAuthor', 'cse'),
(5, 'TD', 'thermodynamic', 3, 500, 2, 'praveen', 'technical publication', '2020-10-12', 2, '2017', 'LocalAuthor', 'mech'),
(10, 'SM', 'solidMechanics', 3, 450, 3, 'savikumar', 'technical publication', '2020-10-12', 3, '2017', 'LocalAuthor', 'mech'),
(11, 'mpmc', 'micro processor and controller', 4, 340, 2, 'harish', 'swchitra', '2018-07-20', 5, '2013', 'LocalAuthor', 'cse'),
(12, 'java', 'java', 5, 600, 2, 'strategynaveen', 'technical', '2020-12-31', 6, '2017', 'LocalAuthor', 'cse'),
(14, 'AT', 'Applied Thermodynamics', 18, 300, 4, 'Tata McGraw Hill', 'surya publication', '2020-12-08', 2, '2017', 'ForeignAuthor', 'mech'),
(21, 'ant', 'angebra number theory', 6, 450, 4, 'ashok', 'swchitra', '2018-08-25', 5, '2017', 'LocalAuthor', 'cse'),
(22, 'toc', 'theory of computation', 8, 700, 2, 'avinash_professional', 'technical', '2017-07-19', 3, '2013', 'LocalAuthor', 'cse'),
(23, 'python', 'python ', 2, 250, 2, 'strategynaveen', 'swchitra', '2020-10-16', 3, '2013', 'LocalAuthor', 'cse'),
(33, 'apce', 'air pollution and control engineering', 1, 560, 4, 'naveen', 'swchitra', '2019-09-18', 2, '2017', 'LocalAuthor', 'cse'),
(34, 'oops', 'object orieneted programming language', 6, 600, 2, 'strategynaveen', 'swchithra', '2020-12-31', 5, '2017', 'LocalAuthor', 'cse'),
(36, 'Geomatics', 'Surveying & Geomatics', 7, 500, 2, 'Tata McGraw Hill', 'Khann publication', '2020-09-29', 8, '2017', 'LocalAuthor', 'civil'),
(46, 'LS', 'Life Science', 34, 450, 4, 'R. Subramanian', 'technical publication', '2020-10-07', 3, '2013', 'LocalAuthor', 'civil'),
(49, 'FM(a)fm', 'Fluid Mechanics and Fluid Machines', 8, 300, 2, 'R. Subramanian', 'lakshmi publication', '2020-05-13', 6, '2018', 'ForeignAuthor', 'mech'),
(52, 'BFE', 'Biology for Engineers', 7, 280, 1, 'mani', 'Khann publication', '2020-10-24', 4, '2017', 'LocalAuthor', 'civil'),
(56, 'SOM', 'Strength of Materials', 45, 280, 2, 'R. Subramanian', 'lakshmi publication', '2021-01-14', 8, '2013', 'LocalAuthor', 'mech'),
(57, 'Fpp', 'Particle & Fluid Particle Processing', 127, 370, 3, 'mani', 'Khann publication', '2020-12-25', 7, '2013', 'ForeignAuthor', 'ece'),
(58, 'WC', 'Water Conservation & Management', 128, 500, 4, 'savikumar', 'technical publication', '2021-01-02', 5, '2017', 'ForeignAuthor', 'ece'),
(61, 'PE', 'Petroleum Engineering', 130, 150, 1, 'savikumar', 'surya publication', '2021-01-01', 1, '2017', 'ForeignAuthor', 'ece'),
(70, 'DD', 'Distributed Databases', 131, 450, 4, 'praveen', 'surya publication', '2021-01-29', 7, '2013', 'LocalAuthor', 'ece'),
(72, 'EG', 'Engineering Geology', 22, 280, 2, 'R. Subramanian', 'surya publication', '2020-10-31', 2, '2017', 'LocalAuthor', 'civil'),
(81, 'he', 'Hydraulic Engineering', 101, 150, 2, 'savikumar', 'lakshmi publication', '2020-10-14', 8, '2017', 'LocalAuthor', 'civil'),
(82, 'EC', ' Electrical Circuit Analysis', 102, 370, 1, 'R. Subramanian', 'Khann publication', '2020-10-01', 5, '2017', 'ForeignAuthor', 'eee'),
(83, 'AN', 'Analog Electronics', 103, 280, 2, 'mani', 'technical publication', '2020-10-03', 2, '2017', 'LocalAuthor', 'eee'),
(84, 'PE', 'Power Electronics', 104, 500, 3, 'savikumar', 'lakshmi publication', '2020-10-08', 3, '2013', 'LocalAuthor', 'eee'),
(85, 'Mpmc', 'Microprocessors', 105, 370, 3, 'savikumar', 'surya publication', '2020-09-30', 8, '2013', 'LocalAuthor', 'civil'),
(86, 'Ss', 'Signals&System', 106, 300, 2, 'Tata McGraw Hill', 'surya publication', '2020-09-27', 8, '2017', 'LocalAuthor', 'eee'),
(87, 'phy', 'Physics -II', 108, 370, 3, 'R. Subramanian', 'surya publication', '2020-10-30', 7, '2013', 'ForeignAuthor', 'eee'),
(92, 'ED', 'Electronic Devices', 112, 450, 1, 'R. Subramanian', 'lakshmi publication', '2020-12-01', 6, '2017', 'ForeignAuthor', 'ece'),
(93, 'Ds', 'Digital System Design', 113, 290, 1, 'mani', 'Khann publication', '2020-11-27', 7, '2017', 'ForeignAuthor', 'ece'),
(95, 'FOC', 'Fiber Optic Communication', 114, 370, 1, 'savikumar', 'Khann publication', '2020-10-31', 8, '2013', 'ForeignAuthor', 'ece'),
(96, 'PE', 'Power Electronics', 121, 150, 1, 'R. Subramanian', 'lakshmi publication', '2020-10-30', 6, '2013', 'ForeignAuthor', 'ece'),
(98, 'ms', 'Material Science', 124, 230, 2, 'praveen', 'Khann publication', '2020-10-31', 3, '2017', 'LocalAuthor', 'ece'),
(126, 'c++', 'c++ language', 4, 400, 1, 'naveen', 'swchitra', '2019-09-25', 1, '2017', 'ForeignAuthor', 'cse'),
(220, 'NM', ' Numerical Methods in Chemical Engineering', 125, 300, 2, 'mani', 'technical publication', '2021-01-02', 6, '2017', 'ForeignAuthor', 'ece'),
(456, 'os', 'operating system', 5, 600, 3, 'balasubramaniyam', 'strategy', '2020-12-31', 2, '2017', 'ForeignAuthor', 'cse'),
(556, '.net', 'component based technology', 7, 560, 3, 'balasubramani', 'technical', '2019-09-27', 1, '2017', 'LocalAuthor', 'cse'),
(1234, 'dpst', 'digital principal system ', 3, 600, 1, 'balasubramani', 'technical', '2020-12-31', 2, '2017', 'LocalAuthor', 'cse');

-- --------------------------------------------------------

--
-- Table structure for table `hod`
--

CREATE TABLE `hod` (
  `username` varchar(70) DEFAULT NULL,
  `gmail` varchar(80) DEFAULT NULL,
  `dept` varchar(90) NOT NULL,
  `address` varchar(90) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `mobileno` bigint(80) DEFAULT NULL,
  `dateogbirth` date DEFAULT NULL,
  `password` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hod`
--

INSERT INTO `hod` (`username`, `gmail`, `dept`, `address`, `gender`, `mobileno`, `dateogbirth`, `password`) VALUES
('kumar', 'naveenkumar709434@gmail.com', 'CIVIL', 'thirupparankundream\r\nmadurai', 'Male', 9942933262, '2020-12-31', 'nk123'),
('naveen', 'naveenkumar709434@gmail.com', 'CSE', 'madurai', 'Male', 9942933262, '2020-12-31', 'naveen'),
('strategy', 'naveenkumar709434@gmail.com', 'ECE', 'madurai', 'Male', 9942933262, '2020-12-31', 'naveen'),
('raghu', 'raghu@gmail.com', 'MECH', 'madurai', 'Male', 7094341464, '2020-12-31', 'raghu');

-- --------------------------------------------------------

--
-- Table structure for table `lib_incharge`
--

CREATE TABLE `lib_incharge` (
  `userid` varchar(80) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `mobile` bigint(80) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `address` varchar(90) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lib_incharge`
--

INSERT INTO `lib_incharge` (`userid`, `name`, `email`, `mobile`, `gender`, `address`, `dob`, `password`) VALUES
('naveen123', 'naveenkumar', 'naveenkumar709434@gmail.com', 6379617916, 'Male', '79/a mettu street \r\nthirupparankundream\r\nmadurai-05', '2001-04-03', 'nk123'),
('naveen321', 'naveenkumar', 'naveenkumar709434@gmail.com', 6379617916, 'Male', '79/a mettu street\r\nthirupparankundream\r\nmadurai', '2020-12-31', 'nk123');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `regno` bigint(60) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `dept` varchar(80) DEFAULT NULL,
  `mobile` bigint(90) DEFAULT NULL,
  `gmail` varchar(90) DEFAULT NULL,
  `gender` varchar(80) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `current_year` varchar(50) DEFAULT NULL,
  `pass` varchar(90) DEFAULT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`regno`, `name`, `dept`, `mobile`, `gmail`, `gender`, `address`, `dob`, `current_year`, `pass`, `image`) VALUES
(19711, 'karuppu', 'mech', 7094341464, 'karuppu@gmail.com', 'Male', 'madurai-05', '2000-01-05', '2nd year', 'nk', 'IMG-20201120-WA0128.jpg'),
(164130, 'navin', 'cse', 7094341464, 'navinkumar@gmail.com', 'Male', 'madurai', '2020-12-31', '3rd Year', 'nk321', 'IMG20190922144544.jpg'),
(910018104036, 'ragu', 'cse', 8608164566, 'ragu@gmail.com', 'Male', 'madurai', '2000-09-12', '3rd Year', 'ragu', 'WhatsApp Image 2020-11-27 at 4.52.56 AM (1).jpeg'),
(910018104302, 'avinash', 'cse', 9894469024, 'avinash@gmail.com', 'Male', 'thirupparankundream\r\nmadurai -05', '2000-04-05', '3rd Year', 'avinash', 'IMG20190827144550.jpg'),
(910018104303, 'bala', 'cse', 987654321, 'bala@gmail.com', 'Male', 'Madurai', '2000-04-18', '4th Year', 'balank', 'Screenshot from 2021-08-22 22-15-32.png'),
(910018104304, 'NaveenKumar', 'cse', 6379617916, 'naveenkumar709434@gmail.com', 'Male', '79/a thirupparankundreammadurai', '2000-04-18', '3rd Year', 'nk', 'IMG_20190427_222624_337.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `stud_order`
--

CREATE TABLE `stud_order` (
  `regno` bigint(60) DEFAULT NULL,
  `name` varchar(80) DEFAULT NULL,
  `dept` varchar(60) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `mobile` bigint(50) DEFAULT NULL,
  `refno` bigint(30) DEFAULT NULL,
  `b_name` varchar(70) DEFAULT NULL,
  `b_count` int(60) DEFAULT NULL,
  `current_year` varchar(60) DEFAULT NULL,
  `gender` varchar(70) DEFAULT NULL,
  `b_dept` varchar(70) DEFAULT NULL,
  `edition` int(30) DEFAULT NULL,
  `rackno` int(40) DEFAULT NULL,
  `regulation` varchar(60) DEFAULT NULL,
  `del_date` date DEFAULT NULL,
  `deuo_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `sub_status` varchar(50) DEFAULT NULL,
  `order_date` varchar(60) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `sub_date` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_order`
--

INSERT INTO `stud_order` (`regno`, `name`, `dept`, `email`, `mobile`, `refno`, `b_name`, `b_count`, `current_year`, `gender`, `b_dept`, `edition`, `rackno`, `regulation`, `del_date`, `deuo_date`, `status`, `sub_status`, `order_date`, `reason`, `sub_date`) VALUES
(910018104304, 'NaveenKumar', 'cse', 'naveenkumar709434@gmail.com', 6379617916, 556, '.net', 1, '3rd Year', 'Male', 'cse', 3, 7, '2017', '2021-08-26', '2021-08-30', 'accepted', 'submited', '16-12-20 : 04:15:13pm', '', '26-08-21 : 02:21:49pm'),
(910018104304, 'NaveenKumar', 'cse', 'naveenkumar709434@gmail.com', 6379617916, 87, 'phy', 1, '3rd Year', 'Male', 'eee', 3, 108, '2013', '2021-08-27', '2021-08-31', 'accepted', 'unsubmited', '16-12-20 : 04:15:45pm', '', ''),
(910018104036, 'ragu', 'cse', 'ragu@gmail.com', 8608164566, 49, 'FM(a)fm', 1, '3rd Year', 'Male', 'mech', 2, 8, '2018', NULL, NULL, 'accepted', NULL, '16-12-20 : 04:24:23pm', '', ''),
(910018104304, 'NaveenKumar', 'cse', 'naveenkumar709434@gmail.com', 6379617916, 23, 'python', 1, '3rd Year', 'Male', 'cse', 2, 2, '2013', '2021-08-19', '2021-08-31', 'accepted', 'submited', '17-12-20 : 07:54:12am', '', '26-08-21 : 02:29:46pm'),
(910018104036, 'ragu', 'cse', 'ragu@gmail.com', 8608164566, 82, 'EC', 1, '3rd Year', 'Male', 'eee', 1, 102, '2017', NULL, NULL, 'accepted', NULL, '30-12-20 : 04:25:15pm', '', ''),
(910018104302, 'avinash', 'cse', 'avinash@gmail.com', 9894469024, 2, 'c', 3, '3rd Year', 'Male', 'cse', 1, 2, '2017', NULL, NULL, 'Rejected', NULL, '26-08-21 : 02:16:01pm', 'sry is invalid book', NULL),
(910018104302, 'avinash', 'cse', 'avinash@gmail.com', 9894469024, 14, 'AT', 2, '3rd Year', 'Male', 'mech', 4, 18, '2017', NULL, NULL, NULL, NULL, '26-08-21 : 02:18:59pm', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_reg`
--
ALTER TABLE `book_reg`
  ADD PRIMARY KEY (`book_ref`);

--
-- Indexes for table `hod`
--
ALTER TABLE `hod`
  ADD PRIMARY KEY (`dept`);

--
-- Indexes for table `lib_incharge`
--
ALTER TABLE `lib_incharge`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`regno`);

--
-- Indexes for table `stud_order`
--
ALTER TABLE `stud_order`
  ADD KEY `regno` (`regno`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `stud_order`
--
ALTER TABLE `stud_order`
  ADD CONSTRAINT `stud_order_ibfk_1` FOREIGN KEY (`regno`) REFERENCES `student` (`regno`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
